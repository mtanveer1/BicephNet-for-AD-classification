Biceph Net:

Model -> Feature-Extractor -> KNN Classifier

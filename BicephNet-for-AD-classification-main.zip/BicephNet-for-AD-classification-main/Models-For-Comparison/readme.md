Added models for comparison:

1. VGG Conv LSTM
2. VGG LSTM 
3. VGG sBiLSTM
4. Eight Layer Large CAT12
